import React, { useEffect, useState } from 'react';
import { ArrowRight, Phone, Mail, MapPin, MessageCircle, Clock3 } from 'lucide-react';
import { businessConfig } from '../config/businessConfig';

export default function Contact() {
  const [form, setForm] = useState({ name: '', phone: '', email: '', product: '', message: '' });
  const [status, setStatus] = useState('');

  useEffect(() => {
    const product = sessionStorage.getItem('marutiEnquiryProduct');
    if (product) {
      setForm((f) => ({ ...f, product }));
      sessionStorage.removeItem('marutiEnquiryProduct');
    }
  }, []);

  const update = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  const submit = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim() || !form.message.trim()) {
      setStatus('Please fill in your name, phone number and message.');
      return;
    }
    setStatus('Form validated. Connect Formspree, Resend, EmailJS or your backend to send enquiries.');
  };

  const whatsappReady = businessConfig.whatsapp && !businessConfig.whatsapp.includes('ADD');

  return (
    <>
      <section className="page-hero contact-hero"><div className="container page-hero-inner"><span className="eyebrow light">Contact Us</span><h1>Tell us what you need.</h1><p>Contact Maruti Electricals for product availability, pricing, bulk requirements or general enquiries.</p></div></section>
      <section className="section contact-section">
        <div className="container contact-grid">
          <div className="contact-details">
            <span className="eyebrow orange">Get in touch</span>
            <h2>Easy to reach. Easy to update.</h2>
            <p>The placeholders below are controlled from one config file, so your final phone, WhatsApp and email only need to be entered once.</p>
            <div className="contact-list">
              <div><span><Phone /></span><div><small>Phone</small><strong>{businessConfig.phone}</strong></div></div>
              <div><span><MessageCircle /></span><div><small>WhatsApp</small><strong>{businessConfig.whatsapp}</strong></div></div>
              <div><span><Mail /></span><div><small>Email</small><strong>{businessConfig.email}</strong></div></div>
              <div><span><MapPin /></span><div><small>Address</small><strong>{businessConfig.address}</strong></div></div>
            </div>
            <div className="config-note"><Clock3 size={18} /><span>Business hours have intentionally not been invented. Add them only when confirmed.</span></div>
          </div>
          <form className="enquiry-form" onSubmit={submit} noValidate>
            <div className="form-head"><span className="eyebrow orange">Product Enquiry</span><h2>Send an enquiry</h2><p>Frontend validation is active. No email is sent until you connect a real form service.</p></div>
            <label>Name *<input value={form.name} onChange={(e) => update('name', e.target.value)} placeholder="Your name" /></label>
            <div className="form-two"><label>Phone Number *<input value={form.phone} onChange={(e) => update('phone', e.target.value)} placeholder="Phone number" /></label><label>Email<input type="email" value={form.email} onChange={(e) => update('email', e.target.value)} placeholder="Email address" /></label></div>
            <label>Product / Requirement<input value={form.product} onChange={(e) => update('product', e.target.value)} placeholder="e.g. House wires, MCBs, bulk requirement" /></label>
            <label>Message *<textarea rows="5" value={form.message} onChange={(e) => update('message', e.target.value)} placeholder="Tell us what you need" /></label>
            <button className="btn btn-primary btn-lg" type="submit">Send Enquiry <ArrowRight size={18} /></button>
            {status && <div className="form-status">{status}</div>}
            {!whatsappReady && <small className="form-helper">WhatsApp button stays in placeholder mode until you add the number in <code>businessConfig.js</code>.</small>}
          </form>
        </div>
      </section>
    </>
  );
}
