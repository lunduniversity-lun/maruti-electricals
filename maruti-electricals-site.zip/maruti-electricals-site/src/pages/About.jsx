import React from 'react';
import { ArrowRight, BadgeCheck, Handshake, Users, Wrench, Home, HardHat, Building2, Store, BriefcaseBusiness } from 'lucide-react';

const principles = [
  [BadgeCheck, 'Reliable Products', 'Focus on practical electrical materials suited to the customer’s requirement.'],
  [Handshake, 'Honest Service', 'Straightforward assistance without invented claims or unnecessary complexity.'],
  [Users, 'Customer Relationships', 'A local-business approach built around repeat customers and long-term relationships.'],
  [Wrench, 'Practical Solutions', 'Help customers identify materials for everyday repairs, installations and project needs.'],
];

const audiences = [
  [Home, 'Homeowners'], [Wrench, 'Electricians'], [HardHat, 'Contractors'], [Building2, 'Builders'], [Store, 'Businesses'], [BriefcaseBusiness, 'Commercial Customers']
];

export default function About({ navigate }) {
  return (
    <>
      <section className="page-hero about-hero"><div className="container page-hero-inner"><span className="eyebrow light">About Maruti Electricals</span><h1>Built on local relationships.</h1><p>Around 30 years in Sikanderpur, serving everyday customers and electrical professionals across Gurgaon.</p></div></section>
      <section className="section story-section"><div className="container story-grid"><div className="story-art"><div className="story-30">30<sup>+</sup></div><span>YEARS IN SIKANDERPUR</span></div><div className="story-copy"><span className="eyebrow orange">Our Story</span><h2>Long-standing, local and accessible.</h2><p>Maruti Electricals has been operating in the Sikanderpur Market area for approximately 30 years. Over that time, the business has served local customers, electricians, contractors, builders and businesses looking for electrical materials.</p><p>Our identity is not about pretending to be a giant corporation. It is about being a dependable local supplier with product knowledge, practical service and an established presence customers can reach easily.</p></div></div></section>
      <section className="section principles-section"><div className="container"><div className="section-heading centered"><span className="eyebrow orange">Our Approach</span><h2>Simple principles that matter.</h2></div><div className="principle-grid">{principles.map(([Icon, title, text]) => <article className="principle-card" key={title}><Icon size={30} /><h3>{title}</h3><p>{text}</p></article>)}</div></div></section>
      <section className="section audience-section"><div className="container"><div className="section-heading heading-row"><div><span className="eyebrow orange">Who We Serve</span><h2>From one switch to larger requirements.</h2></div><p>Retail customers and professionals can enquire for availability, pricing and bulk or project needs.</p></div><div className="audience-grid">{audiences.map(([Icon, label]) => <div className="audience-pill" key={label}><Icon size={22} />{label}</div>)}</div><div className="center-cta"><button className="btn btn-primary" onClick={() => navigate('/contact')}>Talk to us about your requirement <ArrowRight size={17} /></button></div></div></section>
    </>
  );
}
