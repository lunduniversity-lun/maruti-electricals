import React, { useState } from 'react';
import { ArrowRight, BadgeCheck, Cable, ToggleLeft, ShieldCheck, CircleDot, Lightbulb, Fan, Boxes, Wrench, MapPin, Search, PackageCheck, Handshake, IndianRupee, Store, Users } from 'lucide-react';
import { products } from '../data/products';
import ProductCard from '../components/ProductCard';
import ProductModal from '../components/ProductModal';
import { businessConfig } from '../config/businessConfig';

const categories = [
  { name: 'Wires & Cables', icon: Cable, desc: 'House wires, power cables and related electrical wiring.' },
  { name: 'Switches & Sockets', icon: ToggleLeft, desc: 'Modular switches, sockets and everyday switching essentials.' },
  { name: 'MCBs & Distribution Boards', icon: ShieldCheck, desc: 'Circuit protection and distribution solutions.' },
  { name: 'Electrical Pipes & Conduits', icon: CircleDot, desc: 'Conduit and routing products for protected installations.' },
  { name: 'LED Lighting', icon: Lightbulb, desc: 'Bulbs, panels and lighting for varied requirements.' },
  { name: 'Fans & Accessories', icon: Fan, desc: 'Ceiling fans and supporting electrical accessories.' },
  { name: 'Modular Electrical Accessories', icon: Boxes, desc: 'Useful modular accessories and finishing components.' },
  { name: 'Other Electrical Materials', icon: Wrench, desc: 'Additional electrical essentials for projects and repairs.' },
];

const reasons = [
  [BadgeCheck, '30+ Years of Experience', 'Serving customers from the Sikanderpur area for over three decades.'],
  [PackageCheck, 'Wide Product Range', 'Electrical materials for everyday requirements, repairs, construction and projects.'],
  [Handshake, 'Reliable Service', 'Straightforward service from a local business you can depend on.'],
  [IndianRupee, 'Competitive Pricing', 'Competitive pricing for regular purchases and larger requirements.'],
  [Store, 'Local Gurgaon Presence', 'Conveniently located in Sikanderpur, Gurgaon.'],
  [Users, 'Retail & Bulk Requirements', 'For individual customers, electricians, contractors, builders and bulk requirements.'],
];

export default function Home({ navigate }) {
  const [selected, setSelected] = useState(null);
  const featured = products.filter((p) => p.featured).slice(0, 6);
  const goEnquire = (product) => {
    sessionStorage.setItem('marutiEnquiryProduct', product.name);
    setSelected(null);
    navigate('/contact');
  };

  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-copy">
            <div className="trust-chip"><span /> 30+ Years Serving Sikanderpur</div>
            <h1>Your trusted electrical partner in <em>Sikanderpur.</em></h1>
            <p>Quality electrical materials, reliable service, and over three decades of local experience serving Gurgaon.</p>
            <div className="hero-actions">
              <button className="btn btn-primary btn-lg" onClick={() => navigate('/products')}>Explore Products <ArrowRight size={18} /></button>
              <button className="btn btn-ghost btn-lg" onClick={() => navigate('/contact')}>Contact Us</button>
            </div>
            <div className="hero-meta">
              <div><strong>30+</strong><span>Years local presence</span></div>
              <div><strong>8+</strong><span>Core categories</span></div>
              <div><strong>Retail + Bulk</strong><span>Requirements welcome</span></div>
            </div>
          </div>
          <div className="hero-art" aria-label="Electrical product illustration">
            <div className="hero-orbit orbit-one" />
            <div className="hero-orbit orbit-two" />
            <div className="hero-panel main-panel"><ToggleLeft size={82} strokeWidth={1.1} /><span>MODULAR</span><b>SWITCHES</b></div>
            <div className="hero-panel mini-panel mini-a"><Cable size={38} /><span>Wires</span></div>
            <div className="hero-panel mini-panel mini-b"><Lightbulb size={38} /><span>Lighting</span></div>
            <div className="hero-panel mini-panel mini-c"><ShieldCheck size={38} /><span>Protection</span></div>
            <div className="hero-glow" />
          </div>
        </div>
      </section>

      <section className="section category-section">
        <div className="container">
          <div className="section-heading heading-row">
            <div>
              <span className="eyebrow orange">Product Catalogue</span>
              <h2>Electrical products for every requirement.</h2>
            </div>
            <p>From everyday electrical essentials to materials for larger requirements, explore our range.</p>
          </div>
          <div className="category-grid">
            {categories.map((cat) => {
              const Icon = cat.icon;
              return (
                <button className="category-card" key={cat.name} onClick={() => navigate('/products')}>
                  <div className="category-icon"><Icon size={30} strokeWidth={1.5} /></div>
                  <h3>{cat.name}</h3>
                  <p>{cat.desc}</p>
                  <span>View Products <ArrowRight size={15} /></span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <section className="section featured-section">
        <div className="container">
          <div className="section-heading centered">
            <span className="eyebrow orange">Popular Requirements</span>
            <h2>Featured products</h2>
            <p>Sample catalogue items ready to be replaced with your actual stock, brands and product images.</p>
          </div>
          <div className="product-grid featured-grid">
            {featured.map((product) => <ProductCard key={product.id} product={product} onOpen={setSelected} compact />)}
          </div>
          <div className="center-cta"><button className="btn btn-dark" onClick={() => navigate('/products')}>Browse full catalogue <ArrowRight size={17} /></button></div>
        </div>
      </section>

      <section className="section why-section">
        <div className="container">
          <div className="section-heading heading-row">
            <div><span className="eyebrow orange">Why Maruti</span><h2>Local experience. Straightforward service.</h2></div>
            <p>A long-standing Sikanderpur electrical supplier focused on practical requirements rather than unnecessary sales noise.</p>
          </div>
          <div className="reason-grid">
            {reasons.map(([Icon, title, text]) => (
              <article className="reason-card" key={title}><Icon size={26} /><h3>{title}</h3><p>{text}</p></article>
            ))}
          </div>
        </div>
      </section>

      <section className="heritage-section">
        <div className="container heritage-grid">
          <div className="heritage-number"><span>30</span><sup>+</sup><small>YEARS</small></div>
          <div className="heritage-copy">
            <span className="eyebrow light">Established locally</span>
            <h2>30 years of trust in Sikanderpur.</h2>
            <p>For more than 30 years, Maruti Electricals has been part of the Sikanderpur Market area, serving the electrical needs of customers in Gurgaon. Our focus is simple: the right products, dependable service and relationships customers can rely on.</p>
            <button className="btn btn-light" onClick={() => navigate('/about')}>Learn More About Us <ArrowRight size={17} /></button>
          </div>
        </div>
      </section>

      <section className="section find-section">
        <div className="container find-card">
          <div className="find-icon"><Search size={34} /></div>
          <div><span className="eyebrow orange">Need something specific?</span><h2>Tell us what you’re looking for.</h2><p>Get in touch for product availability, pricing, regular purchases, project requirements or bulk enquiries.</p></div>
          <button className="btn btn-primary" onClick={() => navigate('/contact')}>Send Enquiry <ArrowRight size={17} /></button>
        </div>
      </section>

      <section className="section location-section">
        <div className="container location-grid">
          <div className="location-copy">
            <span className="eyebrow orange">Visit us</span>
            <h2>Right in Sikanderpur.</h2>
            <p>Maruti Electricals<br />Gangania Complex, M.G. Road<br />Sikanderpur, DLF, Gurugram<br />Haryana – 122002, India</p>
            <button className="btn btn-dark" onClick={() => navigate('/contact')}>Contact & Directions <ArrowRight size={17} /></button>
          </div>
          <div className="map-placeholder">
            <div className="map-grid" />
            <MapPin size={48} />
            <strong>Sikanderpur</strong>
            <span>Google Maps link can be added in businessConfig.js</span>
          </div>
        </div>
      </section>

      <ProductModal product={selected} onClose={() => setSelected(null)} onEnquire={goEnquire} />
    </>
  );
}
