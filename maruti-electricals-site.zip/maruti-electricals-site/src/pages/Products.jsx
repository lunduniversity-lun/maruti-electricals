import React, { useMemo, useState } from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';
import { products, categories } from '../data/products';
import ProductCard from '../components/ProductCard';
import ProductModal from '../components/ProductModal';

export default function Products({ navigate }) {
  const [category, setCategory] = useState('All Products');
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(null);

  const visible = useMemo(() => products.filter((p) => {
    const matchesCategory = category === 'All Products' || p.category === category;
    const q = query.trim().toLowerCase();
    const matchesQuery = !q || `${p.name} ${p.category} ${p.description} ${p.brand}`.toLowerCase().includes(q);
    return matchesCategory && matchesQuery;
  }), [category, query]);

  const goEnquire = (product) => {
    sessionStorage.setItem('marutiEnquiryProduct', product.name);
    setSelected(null);
    navigate('/contact');
  };

  return (
    <>
      <section className="page-hero products-hero">
        <div className="container page-hero-inner">
          <span className="eyebrow light">Product Catalogue</span>
          <h1>Our Products</h1>
          <p>Explore our range of electrical materials and accessories. Pricing and availability are handled by enquiry.</p>
        </div>
      </section>
      <section className="section products-page">
        <div className="container">
          <div className="catalog-toolbar">
            <div className="search-box"><Search size={19} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search products or categories" aria-label="Search products" /></div>
            <div className="result-count"><SlidersHorizontal size={17} /> {visible.length} products</div>
          </div>
          <div className="filter-row" role="group" aria-label="Product categories">
            {categories.map((cat) => <button key={cat} className={category === cat ? 'filter-pill active' : 'filter-pill'} onClick={() => setCategory(cat)}>{cat}</button>)}
          </div>
          {visible.length ? (
            <div className="product-grid catalogue-grid">{visible.map((p) => <ProductCard key={p.id} product={p} onOpen={setSelected} />)}</div>
          ) : (
            <div className="empty-state"><h3>No matching products</h3><p>Try another category or search term.</p></div>
          )}
        </div>
      </section>
      <ProductModal product={selected} onClose={() => setSelected(null)} onEnquire={goEnquire} />
    </>
  );
}
