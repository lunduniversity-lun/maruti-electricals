// ============================================================
// EDIT THESE VALUES TO UPDATE BUSINESS INFORMATION EVERYWHERE
// ============================================================
export const businessConfig = {
  name: 'Maruti Electricals',
  phone: 'ADD PHONE NUMBER',
  whatsapp: 'ADD WHATSAPP NUMBER',
  email: 'ADD BUSINESS EMAIL',
  address: 'Gangania Complex, M.G. Road, Sikanderpur, DLF, Gurugram, Haryana - 122002',
  shortAddress: 'Sikanderpur, Gurugram, Haryana',
  experience: '30+ years',
  googleMapsUrl: '',
  enquiryMessage: 'Hello Maruti Electricals, I would like to enquire about your electrical products.',
};
