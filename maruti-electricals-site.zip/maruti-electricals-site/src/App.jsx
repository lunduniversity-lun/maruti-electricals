import React, { useEffect, useState } from 'react';
import { Navbar, Footer, WhatsAppButton } from './components/SiteChrome';
import Home from './pages/Home';
import Products from './pages/Products';
import About from './pages/About';
import Contact from './pages/Contact';

const routes = {
  '/': Home,
  '/products': Products,
  '/about': About,
  '/contact': Contact,
};

export default function App() {
  const [path, setPath] = useState(window.location.pathname || '/');

  useEffect(() => {
    const onPopState = () => setPath(window.location.pathname || '/');
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [path]);

  const navigate = (to) => {
    if (window.location.pathname === to) return;
    window.history.pushState({}, '', to);
    setPath(to);
  };

  const Page = routes[path] || Home;

  return (
    <div className="app-shell">
      <Navbar currentPath={path} navigate={navigate} />
      <main>
        <Page navigate={navigate} />
      </main>
      <Footer navigate={navigate} />
      <WhatsAppButton />
    </div>
  );
}
