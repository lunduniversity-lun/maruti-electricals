import React from 'react';
import * as Icons from 'lucide-react';
import { ArrowUpRight } from 'lucide-react';

export default function ProductCard({ product, onOpen, compact = false }) {
  const Icon = Icons[product.icon] || Icons.Package;
  return (
    <article className={`product-card ${compact ? 'product-card--compact' : ''}`}>
      <button className="product-visual" onClick={() => onOpen(product)} aria-label={`View ${product.name}`}>
        {product.image ? <img src={product.image} alt={product.name} loading="lazy" /> : <Icon size={compact ? 54 : 70} strokeWidth={1.35} />}
        <span className="visual-grid" />
      </button>
      <div className="product-copy">
        <span className="eyebrow">{product.category}</span>
        <h3>{product.name}</h3>
        {!compact && <p>{product.description}</p>}
        <div className="product-actions">
          <button className="text-link" onClick={() => onOpen(product)}>View Details <ArrowUpRight size={15} /></button>
          <button className="mini-enquire" onClick={() => onOpen(product)}>Enquire</button>
        </div>
      </div>
    </article>
  );
}
