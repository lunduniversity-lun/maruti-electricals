import React, { useEffect, useState } from 'react';
import { Menu, X, MessageCircle, ArrowUpRight, Phone, Mail, MapPin } from 'lucide-react';
import { businessConfig } from '../config/businessConfig';

export function BrandMark({ light = false }) {
  return (
    <button className={`brand-mark ${light ? 'brand-mark--light' : ''}`} onClick={() => (window.location.href = '/')} aria-label="Maruti Electricals home">
      <span className="brand-script">Maruti</span>
      <span className="brand-sub">ELECTRICALS</span>
    </button>
  );
}

export function Navbar({ currentPath, navigate }) {
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [currentPath]);
  const links = [
    ['/', 'Home'],
    ['/products', 'Products'],
    ['/about', 'About Us'],
    ['/contact', 'Contact Us'],
  ];

  return (
    <>
      <div className="utility-bar">
        <div className="container utility-inner">
          <span>{businessConfig.experience} serving Sikanderpur</span>
          <span className="utility-location"><MapPin size={14} /> Gurugram, Haryana</span>
        </div>
      </div>
      <header className="site-header">
        <div className="container nav-inner">
          <div onClick={() => navigate('/')}><BrandMark /></div>
          <nav className="desktop-nav" aria-label="Primary navigation">
            {links.map(([to, label]) => (
              <button key={to} className={currentPath === to ? 'nav-link active' : 'nav-link'} onClick={() => navigate(to)}>
                {label}
              </button>
            ))}
          </nav>
          <div className="nav-actions">
            <button className="btn btn-primary desktop-cta" onClick={() => navigate('/contact')}>Enquire Now <ArrowUpRight size={17} /></button>
            <button className="menu-btn" onClick={() => setOpen((v) => !v)} aria-label="Toggle menu">
              {open ? <X /> : <Menu />}
            </button>
          </div>
        </div>
        {open && (
          <div className="mobile-panel">
            <div className="container mobile-links">
              {links.map(([to, label]) => (
                <button key={to} className={currentPath === to ? 'mobile-link active' : 'mobile-link'} onClick={() => navigate(to)}>
                  {label}
                </button>
              ))}
              <button className="btn btn-primary mobile-enquire" onClick={() => navigate('/contact')}>Enquire Now</button>
            </div>
          </div>
        )}
      </header>
    </>
  );
}

export function Footer({ navigate }) {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <BrandMark light />
          <p>Trusted electrical materials and solutions in Sikanderpur, Gurgaon.</p>
          <span className="footer-pill">Serving Sikanderpur for 30+ years</span>
        </div>
        <div>
          <h4>Quick Links</h4>
          <button onClick={() => navigate('/')}>Home</button>
          <button onClick={() => navigate('/products')}>Products</button>
          <button onClick={() => navigate('/about')}>About Us</button>
          <button onClick={() => navigate('/contact')}>Contact Us</button>
        </div>
        <div>
          <h4>Contact</h4>
          <p><Phone size={16} /> {businessConfig.phone}</p>
          <p><Mail size={16} /> {businessConfig.email}</p>
          <p><MapPin size={16} /> {businessConfig.shortAddress}</p>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© 2026 Maruti Electricals. All rights reserved.</span>
        <span>Catalogue & enquiry website</span>
      </div>
    </footer>
  );
}

export function WhatsAppButton() {
  const isConfigured = businessConfig.whatsapp && !businessConfig.whatsapp.includes('ADD');
  const href = isConfigured
    ? `https://wa.me/${businessConfig.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(businessConfig.enquiryMessage)}`
    : null;

  if (!isConfigured) {
    return <button className="whatsapp-float placeholder" title="Add WhatsApp number in businessConfig.js"><MessageCircle size={22} /></button>;
  }

  return <a className="whatsapp-float" href={href} target="_blank" rel="noreferrer" aria-label="WhatsApp Maruti Electricals"><MessageCircle size={22} /></a>;
}
