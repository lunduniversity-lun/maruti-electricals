import React from 'react';
import * as Icons from 'lucide-react';
import { X, ArrowRight } from 'lucide-react';

export default function ProductModal({ product, onClose, onEnquire }) {
  if (!product) return null;
  const Icon = Icons[product.icon] || Icons.Package;
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
      <div className="product-modal" role="dialog" aria-modal="true" aria-label={product.name} onMouseDown={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose} aria-label="Close"><X /></button>
        <div className="modal-visual">
          {product.image ? <img src={product.image} alt={product.name} /> : <Icon size={120} strokeWidth={1.15} />}
        </div>
        <div className="modal-copy">
          <span className="eyebrow">{product.category}</span>
          <h2>{product.name}</h2>
          <p>{product.description}</p>
          {product.brand && <div className="detail-row"><span>Brand</span><strong>{product.brand}</strong></div>}
          {product.specifications?.length > 0 && (
            <div className="spec-list">
              {product.specifications.map((spec, i) => <div key={i}>{spec}</div>)}
            </div>
          )}
          <div className="price-note">Price on Enquiry</div>
          <button className="btn btn-primary" onClick={() => onEnquire(product)}>Enquire about this product <ArrowRight size={17} /></button>
        </div>
      </div>
    </div>
  );
}
