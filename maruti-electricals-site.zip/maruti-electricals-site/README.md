# Maruti Electricals Website

A responsive catalogue + enquiry website inspired by the product-first structure and premium merchandising feel of large electrical brands, without copying Havells branding or proprietary layouts.

## Fastest way to use it

The `deploy/` folder is a zero-dependency static build. Upload its contents directly to Netlify, Cloudflare Pages, GitHub Pages, cPanel, or any normal web host.

Edit business details at the top of `deploy/app.js` in the `BUSINESS` object.
Edit the product catalogue in the `PRODUCTS` array in the same file.

Pages:
- `index.html` — Home
- `products.html` — Catalogue with category filters/search and product modal
- `about.html` — About/heritage
- `contact.html` — Contact and validated enquiry form UI

## React source

The `src/` folder contains a React/Vite version with centralized configuration/data files. The sandbox could not complete `npm install`, so the verified handoff includes the no-build `deploy/` version as the immediately usable build.

## Before launch

Replace placeholders for phone, WhatsApp and email. Add real product images/brands/specifications. Connect the contact form to Formspree, Resend, EmailJS or your backend. Add a confirmed Google Maps URL and business hours only when available.
